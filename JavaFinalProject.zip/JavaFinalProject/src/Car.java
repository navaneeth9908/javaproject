
public class Car extends Vehicle{
	 private static final String VEHICLE_TYPE = "Car";
	    
	    private double bootspace;
	    private String geartype;
	    private int airbags ;

	    public Car(String make, String model, String plate, double bootspace, String geartype, int airbags) {
	        super(make, plate, model);
	        this.bootspace = bootspace;
	        this.geartype = geartype;
	        this.airbags = airbags;
	    }

	    @Override
	    public String getVehicleType() {
	        return VEHICLE_TYPE;
	    }
}
