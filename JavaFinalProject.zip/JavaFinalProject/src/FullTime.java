
public class FullTime extends Employee{
	 
    private final double salary;
    private final double bonus;

    public FullTime(String name, int age, double salary, double bonus) {
        super(name, age);
        this.salary = salary;
        this.bonus = bonus;
    }
    
        public FullTime(String name, int age, double salary, double bonus, Vehicle vehicle) {
        super(name, age, vehicle);
        this.salary = salary;
        this.bonus = bonus;
    }

    @Override
    public double calcEarnings() {
        return salary + bonus;
    }

    @Override
    public String getTypeOfEmployee() {
        return "Full Time";
    }

    @Override
    public String printMyData() {
        String data = super.printMyData() 
                + "\n - Salary: " + Util.toCurrencyFormatFrom(salary) 
                + "\n - Bonus: " + Util.toCurrencyFormatFrom(bonus) 
                + "\n - Earnings: " + Util.toCurrencyFormatFrom(calcEarnings());
        
        return data;
    }
    
    
}
