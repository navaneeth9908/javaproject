import java.util.ArrayList;
import java.util.List;
public class Payroll {
	 private List<Employee> employees;
	    private double total;

	    public Payroll() {
	        employees = new ArrayList<>();
	        total = 0;
	    }
	    
	    public Payroll(List<Employee> employees) {
	        this.employees = employees;
	    }
	    
	    public void addEmployee(Employee employee) {
	        employees.add(employee);
	        total += employee.calcEarnings();
	    }
	    
	    public void print() {
	        
	        for (Employee e : employees) {
	            System.out.println(e.printMyData());
	        }
	        
	        System.out.println("\n-------------------------------------------");
	        System.out.println("\n");
	        System.out.println("TOTAL PAYROLL: " + Util.toCurrencyFormatFrom(total) + " Canadian Dollars\n");
	    }
	    
}
