
public abstract class Vehicle implements IPrintable{
	private String make;
    private String model;
    private String plate;

    public Vehicle(String make, String model, String plate) {
        this.make = make;
        this.model = model;
        this.plate = plate;
    }

    public String getMake() {
        return make;
    }

    public String getModel() {
        return model;
    }

    public String getPlate() {
        return plate;
    }
    
    public abstract String getVehicleType();

    @Override
    public String printMyData() {
        return String.format(" - Make: %s\n - Model: %s\n - Plate: %s", make, model, plate);
    }
}
