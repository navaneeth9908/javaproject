import java.math.BigDecimal;
import java.text.NumberFormat;

public class Util {
private static final NumberFormat FORMATTER = NumberFormat.getCurrencyInstance();
    
    public static String toCurrencyFormatFrom(double value) {   
        return FORMATTER.format(value);
    }
    
    public static String toCurrencyFormatFrom(BigDecimal value) {
        return FORMATTER.format(value);
    }
}
