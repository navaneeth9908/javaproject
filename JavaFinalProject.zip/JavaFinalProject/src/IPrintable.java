
public interface IPrintable {
	public String printMyData();
}
