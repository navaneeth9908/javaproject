
public class Intern extends Employee{
	private String schoolName;
    private double fixedSalary;

    public Intern(String name, int age, String schoolName, double fixedSalary) {
        super(name, age);
        this.schoolName = schoolName;
        this.fixedSalary = fixedSalary;
    }
    
    public Intern(String name, int age, String schoolName, double fixedSalary, Vehicle vehicle) {
        super(name, age, vehicle);
        this.schoolName = schoolName;
        this.fixedSalary = fixedSalary;
    }

    @Override
    public String getTypeOfEmployee() {
        return "Intern";
    }

    @Override
    public String printMyData() {
        return super.printMyData()
                + "\n - School Name: " + schoolName
                + "\n - Earnings: " + Util.toCurrencyFormatFrom(calcEarnings());
    }
}
