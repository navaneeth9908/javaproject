
public class PartTime extends Employee {

	 
    private final double rate;
    private final int hoursWorked;

    public PartTime(String name, int age, double rate, int hoursWorked) {
        super(name, age);
        this.rate = rate;
        this.hoursWorked = hoursWorked;
    }
    
    public PartTime(String name, int age, double rate, int hoursWorked, Vehicle vehicle) {
        super(name, age, vehicle);
        this.rate = rate;
        this.hoursWorked = hoursWorked;
    }

    public double getRate() {
        return rate;
    }

    public int getHoursWorked() {
        return hoursWorked;
    }

    @Override
    public double calcEarnings() {
        return rate * hoursWorked;
    }

    @Override
    public String getTypeOfEmployee() {
        return "Part Time";
    }

    @Override
    public String printMyData() {
        return super.printMyData() 
                + "\n - Rate: " + rate
                + "\n - Hours Worked: " + hoursWorked;
    }

}
