
public class FinalProject {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 Motorcycle moto1 = new Motorcycle("Royal Enfield", "Classic 350", "TS024733", 350, "Street", "Standard");
	        Motorcycle moto2 = new Motorcycle("Kawasaki", "Ninja 300", "TS023456", 300, "Racing", "Sport");

	        Car car1 = new Car("Volvo", "Xc40", "TS093909", 395.0, "Automatic", 4);
	        Car car2 = new Car("Lamborghini", "Urus", "TS07877", 3500, "Manual", 5);

	        FullTime ft1 = new FullTime("Peter", 23, 45000, 1500, car1);
	        Employee ft2 = new FullTime("Georgia", 28, 60000, 5000);
	        Employee pt1 = new CommissionBasedPartTime("James", 30, 190, 25, 15, car1);
	        Employee pt2 = new CommissionBasedPartTime("Katherine", 22, 20, 80, 10, moto1);
	        Employee pt3 = new FixedBasedPartTime("Tom", 27, 25, 85, 800, moto2);
	        Employee pt4 = new FixedBasedPartTime("Evelyn", 20, 50, 145, 1300);
	        Employee it1 = new Intern("Mark", 15, "WoofCenter", 1000.0, car2);
	        Employee it2 = new Intern("Harper", 15, "JKWoofCenter", 1100.0);
	        
	        Payroll payroll = new Payroll();
	        
	        payroll.addEmployee(ft1);
	        payroll.addEmployee(ft2);
	        payroll.addEmployee(pt1);
	        payroll.addEmployee(pt2);
	        payroll.addEmployee(pt3);
	        payroll.addEmployee(pt4);
	        payroll.addEmployee(it1);
	        payroll.addEmployee(it2);

	        payroll.print();
	    }
	}


